/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QTabWidget *tabWidget;
    QWidget *tab;
    QTabWidget *tabWidget_2;
    QWidget *tab_25;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLabel *label_4;
    QLineEdit *lineEdit_3;
    QLabel *label_5;
    QLineEdit *email;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_11;
    QLineEdit *lineEdit_6;
    QLineEdit *lineEdit_7;
    QLineEdit *lineEdit_8;
    QPushButton *ajoutparents;
    QTableView *tableaffiche;
    QPushButton *modifierparents;
    QPushButton *affichage_2;
    QLabel *label_3;
    QLineEdit *le_id_sup;
    QPushButton *pushButton_supprimer;
    QWidget *tab_2;
    QLabel *id;
    QLabel *nom;
    QLabel *prenom;
    QLineEdit *id_line;
    QLineEdit *linenom;
    QLineEdit *lineprenom;
    QPushButton *ajouter_enfants;
    QPushButton *modifier_enfants;
    QTableView *tableaffichage_enfants;
    QLabel *label_6;
    QLineEdit *line_ID_sup_enf;
    QPushButton *suppression_enf;
    QPushButton *quitter;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(743, 357);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 781, 291));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        tabWidget_2 = new QTabWidget(tab);
        tabWidget_2->setObjectName(QStringLiteral("tabWidget_2"));
        tabWidget_2->setGeometry(QRect(0, 0, 751, 281));
        tab_25 = new QWidget();
        tab_25->setObjectName(QStringLiteral("tab_25"));
        label = new QLabel(tab_25);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(0, 0, 81, 16));
        label_2 = new QLabel(tab_25);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(0, 20, 111, 16));
        lineEdit = new QLineEdit(tab_25);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(90, 0, 113, 20));
        lineEdit_2 = new QLineEdit(tab_25);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(110, 20, 113, 20));
        label_4 = new QLabel(tab_25);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(10, 40, 61, 16));
        lineEdit_3 = new QLineEdit(tab_25);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(120, 40, 113, 20));
        label_5 = new QLabel(tab_25);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(0, 60, 111, 16));
        email = new QLineEdit(tab_25);
        email->setObjectName(QStringLiteral("email"));
        email->setGeometry(QRect(120, 60, 113, 20));
        label_7 = new QLabel(tab_25);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(0, 100, 111, 16));
        label_8 = new QLabel(tab_25);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(0, 120, 111, 16));
        label_11 = new QLabel(tab_25);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(0, 140, 111, 16));
        lineEdit_6 = new QLineEdit(tab_25);
        lineEdit_6->setObjectName(QStringLiteral("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(120, 100, 113, 20));
        lineEdit_6->setEchoMode(QLineEdit::Password);
        lineEdit_7 = new QLineEdit(tab_25);
        lineEdit_7->setObjectName(QStringLiteral("lineEdit_7"));
        lineEdit_7->setGeometry(QRect(120, 120, 113, 20));
        lineEdit_7->setEchoMode(QLineEdit::Password);
        lineEdit_8 = new QLineEdit(tab_25);
        lineEdit_8->setObjectName(QStringLiteral("lineEdit_8"));
        lineEdit_8->setGeometry(QRect(120, 140, 113, 20));
        ajoutparents = new QPushButton(tab_25);
        ajoutparents->setObjectName(QStringLiteral("ajoutparents"));
        ajoutparents->setGeometry(QRect(20, 210, 75, 23));
        tableaffiche = new QTableView(tab_25);
        tableaffiche->setObjectName(QStringLiteral("tableaffiche"));
        tableaffiche->setGeometry(QRect(250, 0, 481, 192));
        modifierparents = new QPushButton(tab_25);
        modifierparents->setObjectName(QStringLiteral("modifierparents"));
        modifierparents->setGeometry(QRect(250, 210, 75, 23));
        affichage_2 = new QPushButton(tab_25);
        affichage_2->setObjectName(QStringLiteral("affichage_2"));
        affichage_2->setGeometry(QRect(140, 210, 75, 23));
        label_3 = new QLabel(tab_25);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(380, 210, 47, 13));
        le_id_sup = new QLineEdit(tab_25);
        le_id_sup->setObjectName(QStringLiteral("le_id_sup"));
        le_id_sup->setGeometry(QRect(460, 210, 113, 20));
        pushButton_supprimer = new QPushButton(tab_25);
        pushButton_supprimer->setObjectName(QStringLiteral("pushButton_supprimer"));
        pushButton_supprimer->setGeometry(QRect(610, 210, 75, 23));
        tabWidget_2->addTab(tab_25, QString());
        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        id = new QLabel(tab_2);
        id->setObjectName(QStringLiteral("id"));
        id->setGeometry(QRect(10, 20, 47, 13));
        nom = new QLabel(tab_2);
        nom->setObjectName(QStringLiteral("nom"));
        nom->setGeometry(QRect(0, 50, 91, 16));
        prenom = new QLabel(tab_2);
        prenom->setObjectName(QStringLiteral("prenom"));
        prenom->setGeometry(QRect(0, 90, 101, 20));
        id_line = new QLineEdit(tab_2);
        id_line->setObjectName(QStringLiteral("id_line"));
        id_line->setGeometry(QRect(120, 20, 113, 20));
        linenom = new QLineEdit(tab_2);
        linenom->setObjectName(QStringLiteral("linenom"));
        linenom->setGeometry(QRect(120, 50, 113, 20));
        lineprenom = new QLineEdit(tab_2);
        lineprenom->setObjectName(QStringLiteral("lineprenom"));
        lineprenom->setGeometry(QRect(120, 90, 113, 20));
        ajouter_enfants = new QPushButton(tab_2);
        ajouter_enfants->setObjectName(QStringLiteral("ajouter_enfants"));
        ajouter_enfants->setGeometry(QRect(60, 150, 75, 23));
        modifier_enfants = new QPushButton(tab_2);
        modifier_enfants->setObjectName(QStringLiteral("modifier_enfants"));
        modifier_enfants->setGeometry(QRect(220, 150, 75, 23));
        tableaffichage_enfants = new QTableView(tab_2);
        tableaffichage_enfants->setObjectName(QStringLiteral("tableaffichage_enfants"));
        tableaffichage_enfants->setGeometry(QRect(320, 10, 391, 241));
        label_6 = new QLabel(tab_2);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(10, 200, 47, 13));
        line_ID_sup_enf = new QLineEdit(tab_2);
        line_ID_sup_enf->setObjectName(QStringLiteral("line_ID_sup_enf"));
        line_ID_sup_enf->setGeometry(QRect(70, 200, 113, 20));
        suppression_enf = new QPushButton(tab_2);
        suppression_enf->setObjectName(QStringLiteral("suppression_enf"));
        suppression_enf->setGeometry(QRect(220, 200, 75, 23));
        quitter = new QPushButton(tab_2);
        quitter->setObjectName(QStringLiteral("quitter"));
        quitter->setGeometry(QRect(0, 0, 31, 16));
        tabWidget->addTab(tab_2, QString());
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 743, 21));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(0);
        tabWidget_2->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Gestion des Clients", Q_NULLPTR));
        label->setText(QApplication::translate("MainWindow", "Nom de famille", Q_NULLPTR));
        label_2->setText(QApplication::translate("MainWindow", "Pr\303\251nom de reponsable", Q_NULLPTR));
        label_4->setText(QApplication::translate("MainWindow", "cin ", Q_NULLPTR));
        label_5->setText(QApplication::translate("MainWindow", "email resp", Q_NULLPTR));
        label_7->setText(QApplication::translate("MainWindow", "password", Q_NULLPTR));
        label_8->setText(QApplication::translate("MainWindow", "confirm password ", Q_NULLPTR));
        label_11->setText(QApplication::translate("MainWindow", "pays ", Q_NULLPTR));
        ajoutparents->setText(QApplication::translate("MainWindow", "ajouter", Q_NULLPTR));
        modifierparents->setText(QApplication::translate("MainWindow", "modifier ", Q_NULLPTR));
        affichage_2->setText(QApplication::translate("MainWindow", "affichage", Q_NULLPTR));
        label_3->setText(QApplication::translate("MainWindow", "CIN", Q_NULLPTR));
        pushButton_supprimer->setText(QApplication::translate("MainWindow", "supprimer", Q_NULLPTR));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_25), QApplication::translate("MainWindow", "Tab 1", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("MainWindow", "Tab 1", Q_NULLPTR));
        id->setText(QApplication::translate("MainWindow", "ID ", Q_NULLPTR));
        nom->setText(QApplication::translate("MainWindow", "nom de l'enfants ", Q_NULLPTR));
        prenom->setText(QApplication::translate("MainWindow", "prenom de l'enfants ", Q_NULLPTR));
        ajouter_enfants->setText(QApplication::translate("MainWindow", "ajouter ", Q_NULLPTR));
        modifier_enfants->setText(QApplication::translate("MainWindow", "modifier", Q_NULLPTR));
        label_6->setText(QApplication::translate("MainWindow", "ID supp", Q_NULLPTR));
        suppression_enf->setText(QApplication::translate("MainWindow", "supprimer", Q_NULLPTR));
        quitter->setText(QApplication::translate("MainWindow", "*", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("MainWindow", "Page", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
