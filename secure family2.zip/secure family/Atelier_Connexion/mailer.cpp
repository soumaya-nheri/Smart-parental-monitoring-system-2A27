#include "mailer.h"
#include "ui_mailer.h"

Mailer::Mailer(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Mailer)
{
    ui->setupUi(this);
    connect(ui->sendBtn_2, SIGNAL(clicked()),this, SLOT(sendMail()));
    connect(ui->exitBtn_2, SIGNAL(clicked()),this, SLOT(close()));
}

Mailer::~Mailer()
{
    delete ui;
}

void Mailer::sendMail()
{
    Smtp* smtp = new Smtp(ui->uname_2->text(), ui->paswd_2->text(), ui->server_2->text(), ui->port_2->text().toInt());
    connect(smtp, SIGNAL(status(QString)), this, SLOT(mailSent(QString)));


    smtp->sendMail(ui->uname_2->text(), ui->rcpt_2->text() , ui->subject_2->text(),0);
}

void Mailer::mailSent(QString status)
{
    if(status == "Message sent")
       { QMessageBox::critical(nullptr, QObject::tr("L'email"),
                    QObject::tr("email envoyé.\n"
                                ), QMessageBox::Cancel);}}



void Mailer::on_pushButton_clicked()
{

    Mailer::setStyleSheet("background-color: white");
    ui->label_8->setStyleSheet("color: black");
    ui->label_9->setStyleSheet("color: black");
    ui->label_10->setStyleSheet("color: black");
    ui->label_11->setStyleSheet("color: black");
    ui->label_12->setStyleSheet("color: black");
    ui->label_13->setStyleSheet("color: black");
    ui->label_14->setStyleSheet("color: black");
    ui->pushButton->setStyleSheet("background-color:#c4c4c4");
    ui->pushButton_5->setStyleSheet("background-color:#c4c4c4");
    ui->sendBtn_2->setStyleSheet("background-color:#c4c4c4");
    ui->exitBtn_2->setStyleSheet("background-color:#c4c4c4");
}

void Mailer::on_pushButton_5_clicked()
{
    Mailer::setStyleSheet("background-color: black");
    ui->label_8->setStyleSheet("color: white");
    ui->label_9->setStyleSheet("color: white");
    ui->label_10->setStyleSheet("color: white");
    ui->label_11->setStyleSheet("color: white");
    ui->label_12->setStyleSheet("color: white");
    ui->label_13->setStyleSheet("color: white");
    ui->label_14->setStyleSheet("color: white");
    ui->pushButton->setStyleSheet("background-color:#c4c4c4");
    ui->pushButton_5->setStyleSheet("background-color:#c4c4c4");
    ui->sendBtn_2->setStyleSheet("background-color:#c4c4c4");
    ui->exitBtn_2->setStyleSheet("background-color:#c4c4c4");
}
