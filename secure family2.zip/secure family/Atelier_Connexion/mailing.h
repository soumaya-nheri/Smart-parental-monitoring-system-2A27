#ifndef MAILING_H
#define MAILING_H


class mailing
{
public:
    mailing();
};

#endif // MAILING_H
