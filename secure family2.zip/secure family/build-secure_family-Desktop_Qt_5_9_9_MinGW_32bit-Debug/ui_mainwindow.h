/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QTabWidget *tabWidget;
    QWidget *tab;
    QTabWidget *tabWidget_2;
    QWidget *tab_25;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLabel *label_4;
    QLineEdit *lineEdit_3;
    QLabel *label_5;
    QLineEdit *email;
    QLabel *label_7;
    QLabel *label_11;
    QLineEdit *lineEdit_6;
    QLineEdit *lineEdit_8;
    QPushButton *ajoutparents;
    QPushButton *modifierparents;
    QWidget *tab_3;
    QTableView *tableaffiche;
    QLineEdit *recherche_2;
    QPushButton *recherche;
    QPushButton *trier;
    QPushButton *pdf;
    QPushButton *pB_email;
    QWidget *tab_4;
    QLabel *label_3;
    QLineEdit *le_id_sup;
    QPushButton *pushButton_supprimer;
    QWidget *tab_2;
    QTabWidget *tabWidget_3;
    QWidget *tab_5;
    QLineEdit *id_line;
    QLineEdit *linenom;
    QLineEdit *lineprenom;
    QLabel *nom;
    QLabel *id;
    QLabel *prenom;
    QPushButton *quitter;
    QPushButton *ajouter_enfants;
    QPushButton *modifier_enfants;
    QWidget *tab_6;
    QTableView *tableaffichage_enfants;
    QPushButton *trier_2;
    QPushButton *pdf_2;
    QPushButton *recherche_3;
    QLineEdit *idrecherche;
    QWidget *tab_7;
    QLineEdit *line_ID_sup_enf;
    QLabel *label_6;
    QPushButton *suppression_enf;
    QWidget *tab_8;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(743, 357);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(0, 20, 781, 291));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        tabWidget_2 = new QTabWidget(tab);
        tabWidget_2->setObjectName(QStringLiteral("tabWidget_2"));
        tabWidget_2->setGeometry(QRect(0, 0, 751, 281));
        tab_25 = new QWidget();
        tab_25->setObjectName(QStringLiteral("tab_25"));
        label = new QLabel(tab_25);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(20, 40, 81, 16));
        label_2 = new QLabel(tab_25);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(0, 80, 111, 16));
        lineEdit = new QLineEdit(tab_25);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(130, 30, 113, 20));
        lineEdit_2 = new QLineEdit(tab_25);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(130, 80, 113, 20));
        label_4 = new QLabel(tab_25);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(10, 130, 61, 16));
        lineEdit_3 = new QLineEdit(tab_25);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(130, 120, 113, 20));
        label_5 = new QLabel(tab_25);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(430, 30, 91, 20));
        email = new QLineEdit(tab_25);
        email->setObjectName(QStringLiteral("email"));
        email->setGeometry(QRect(530, 30, 113, 20));
        label_7 = new QLabel(tab_25);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(460, 80, 61, 16));
        label_11 = new QLabel(tab_25);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(480, 120, 41, 16));
        lineEdit_6 = new QLineEdit(tab_25);
        lineEdit_6->setObjectName(QStringLiteral("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(530, 80, 113, 20));
        lineEdit_6->setEchoMode(QLineEdit::Password);
        lineEdit_8 = new QLineEdit(tab_25);
        lineEdit_8->setObjectName(QStringLiteral("lineEdit_8"));
        lineEdit_8->setGeometry(QRect(530, 120, 113, 20));
        ajoutparents = new QPushButton(tab_25);
        ajoutparents->setObjectName(QStringLiteral("ajoutparents"));
        ajoutparents->setGeometry(QRect(240, 180, 75, 23));
        modifierparents = new QPushButton(tab_25);
        modifierparents->setObjectName(QStringLiteral("modifierparents"));
        modifierparents->setGeometry(QRect(400, 180, 75, 23));
        tabWidget_2->addTab(tab_25, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        tableaffiche = new QTableView(tab_3);
        tableaffiche->setObjectName(QStringLiteral("tableaffiche"));
        tableaffiche->setGeometry(QRect(100, 0, 481, 192));
        recherche_2 = new QLineEdit(tab_3);
        recherche_2->setObjectName(QStringLiteral("recherche_2"));
        recherche_2->setGeometry(QRect(130, 200, 281, 20));
        recherche = new QPushButton(tab_3);
        recherche->setObjectName(QStringLiteral("recherche"));
        recherche->setGeometry(QRect(490, 200, 75, 23));
        trier = new QPushButton(tab_3);
        trier->setObjectName(QStringLiteral("trier"));
        trier->setGeometry(QRect(620, 110, 75, 23));
        pdf = new QPushButton(tab_3);
        pdf->setObjectName(QStringLiteral("pdf"));
        pdf->setGeometry(QRect(640, 50, 31, 21));
        pB_email = new QPushButton(tab_3);
        pB_email->setObjectName(QStringLiteral("pB_email"));
        pB_email->setGeometry(QRect(0, 60, 75, 23));
        tabWidget_2->addTab(tab_3, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QStringLiteral("tab_4"));
        label_3 = new QLabel(tab_4);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(80, 90, 47, 13));
        le_id_sup = new QLineEdit(tab_4);
        le_id_sup->setObjectName(QStringLiteral("le_id_sup"));
        le_id_sup->setGeometry(QRect(140, 90, 211, 20));
        pushButton_supprimer = new QPushButton(tab_4);
        pushButton_supprimer->setObjectName(QStringLiteral("pushButton_supprimer"));
        pushButton_supprimer->setGeometry(QRect(390, 90, 75, 23));
        tabWidget_2->addTab(tab_4, QString());
        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        tabWidget_3 = new QTabWidget(tab_2);
        tabWidget_3->setObjectName(QStringLiteral("tabWidget_3"));
        tabWidget_3->setGeometry(QRect(0, 0, 741, 271));
        tab_5 = new QWidget();
        tab_5->setObjectName(QStringLiteral("tab_5"));
        id_line = new QLineEdit(tab_5);
        id_line->setObjectName(QStringLiteral("id_line"));
        id_line->setGeometry(QRect(240, 20, 113, 20));
        linenom = new QLineEdit(tab_5);
        linenom->setObjectName(QStringLiteral("linenom"));
        linenom->setGeometry(QRect(240, 60, 113, 20));
        lineprenom = new QLineEdit(tab_5);
        lineprenom->setObjectName(QStringLiteral("lineprenom"));
        lineprenom->setGeometry(QRect(240, 100, 113, 20));
        nom = new QLabel(tab_5);
        nom->setObjectName(QStringLiteral("nom"));
        nom->setGeometry(QRect(130, 60, 91, 16));
        id = new QLabel(tab_5);
        id->setObjectName(QStringLiteral("id"));
        id->setGeometry(QRect(180, 30, 47, 13));
        prenom = new QLabel(tab_5);
        prenom->setObjectName(QStringLiteral("prenom"));
        prenom->setGeometry(QRect(120, 100, 101, 20));
        quitter = new QPushButton(tab_5);
        quitter->setObjectName(QStringLiteral("quitter"));
        quitter->setGeometry(QRect(0, 10, 31, 16));
        ajouter_enfants = new QPushButton(tab_5);
        ajouter_enfants->setObjectName(QStringLiteral("ajouter_enfants"));
        ajouter_enfants->setGeometry(QRect(260, 150, 75, 23));
        modifier_enfants = new QPushButton(tab_5);
        modifier_enfants->setObjectName(QStringLiteral("modifier_enfants"));
        modifier_enfants->setGeometry(QRect(520, 80, 75, 23));
        tabWidget_3->addTab(tab_5, QString());
        tab_6 = new QWidget();
        tab_6->setObjectName(QStringLiteral("tab_6"));
        tableaffichage_enfants = new QTableView(tab_6);
        tableaffichage_enfants->setObjectName(QStringLiteral("tableaffichage_enfants"));
        tableaffichage_enfants->setGeometry(QRect(10, 10, 491, 231));
        trier_2 = new QPushButton(tab_6);
        trier_2->setObjectName(QStringLiteral("trier_2"));
        trier_2->setGeometry(QRect(620, 20, 75, 23));
        pdf_2 = new QPushButton(tab_6);
        pdf_2->setObjectName(QStringLiteral("pdf_2"));
        pdf_2->setGeometry(QRect(620, 60, 71, 21));
        recherche_3 = new QPushButton(tab_6);
        recherche_3->setObjectName(QStringLiteral("recherche_3"));
        recherche_3->setGeometry(QRect(580, 180, 75, 23));
        idrecherche = new QLineEdit(tab_6);
        idrecherche->setObjectName(QStringLiteral("idrecherche"));
        idrecherche->setGeometry(QRect(560, 140, 113, 20));
        tabWidget_3->addTab(tab_6, QString());
        tab_7 = new QWidget();
        tab_7->setObjectName(QStringLiteral("tab_7"));
        line_ID_sup_enf = new QLineEdit(tab_7);
        line_ID_sup_enf->setObjectName(QStringLiteral("line_ID_sup_enf"));
        line_ID_sup_enf->setGeometry(QRect(162, 90, 191, 20));
        label_6 = new QLabel(tab_7);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(100, 100, 47, 13));
        suppression_enf = new QPushButton(tab_7);
        suppression_enf->setObjectName(QStringLiteral("suppression_enf"));
        suppression_enf->setGeometry(QRect(420, 90, 75, 23));
        tabWidget_3->addTab(tab_7, QString());
        tabWidget->addTab(tab_2, QString());
        tab_8 = new QWidget();
        tab_8->setObjectName(QStringLiteral("tab_8"));
        tabWidget->addTab(tab_8, QString());
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 743, 21));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(1);
        tabWidget_2->setCurrentIndex(1);
        tabWidget_3->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Gestion des Clients", Q_NULLPTR));
        label->setText(QApplication::translate("MainWindow", "Nom de famille", Q_NULLPTR));
        label_2->setText(QApplication::translate("MainWindow", "Pr\303\251nom de reponsable", Q_NULLPTR));
        label_4->setText(QApplication::translate("MainWindow", "CIN", Q_NULLPTR));
        label_5->setText(QApplication::translate("MainWindow", "email responsable", Q_NULLPTR));
        label_7->setText(QApplication::translate("MainWindow", "password", Q_NULLPTR));
        label_11->setText(QApplication::translate("MainWindow", "pays ", Q_NULLPTR));
        ajoutparents->setText(QApplication::translate("MainWindow", "ajouter", Q_NULLPTR));
        modifierparents->setText(QApplication::translate("MainWindow", "modifier ", Q_NULLPTR));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_25), QApplication::translate("MainWindow", "ajouter", Q_NULLPTR));
        recherche->setText(QApplication::translate("MainWindow", "recherche", Q_NULLPTR));
        trier->setText(QApplication::translate("MainWindow", "trier", Q_NULLPTR));
        pdf->setText(QApplication::translate("MainWindow", "PDF", Q_NULLPTR));
        pB_email->setText(QApplication::translate("MainWindow", "mail", Q_NULLPTR));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_3), QApplication::translate("MainWindow", "affichage", Q_NULLPTR));
        label_3->setText(QApplication::translate("MainWindow", "CIN", Q_NULLPTR));
        pushButton_supprimer->setText(QApplication::translate("MainWindow", "supprimer", Q_NULLPTR));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_4), QApplication::translate("MainWindow", "suppression", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("MainWindow", "famille", Q_NULLPTR));
        nom->setText(QApplication::translate("MainWindow", "nom de l'enfants ", Q_NULLPTR));
        id->setText(QApplication::translate("MainWindow", "ID ", Q_NULLPTR));
        prenom->setText(QApplication::translate("MainWindow", "prenom de l'enfants ", Q_NULLPTR));
        quitter->setText(QApplication::translate("MainWindow", "*", Q_NULLPTR));
        ajouter_enfants->setText(QApplication::translate("MainWindow", "ajouter ", Q_NULLPTR));
        modifier_enfants->setText(QApplication::translate("MainWindow", "modifier", Q_NULLPTR));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_5), QApplication::translate("MainWindow", "ajouter", Q_NULLPTR));
        trier_2->setText(QApplication::translate("MainWindow", "trier", Q_NULLPTR));
        pdf_2->setText(QApplication::translate("MainWindow", "PDF", Q_NULLPTR));
        recherche_3->setText(QApplication::translate("MainWindow", "recherche", Q_NULLPTR));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_6), QApplication::translate("MainWindow", "affichage", Q_NULLPTR));
        label_6->setText(QApplication::translate("MainWindow", "ID supp", Q_NULLPTR));
        suppression_enf->setText(QApplication::translate("MainWindow", "supprimer", Q_NULLPTR));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_7), QApplication::translate("MainWindow", "supprimer", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("MainWindow", "enfant", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_8), QApplication::translate("MainWindow", "Page", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
