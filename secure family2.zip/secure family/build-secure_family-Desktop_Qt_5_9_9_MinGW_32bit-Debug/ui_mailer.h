/********************************************************************************
** Form generated from reading UI file 'mailer.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAILER_H
#define UI_MAILER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QWidget *layoutWidget;
    QFormLayout *formLayout_2;
    QLabel *label_9;
    QLineEdit *server_2;
    QLabel *label_10;
    QLineEdit *port_2;
    QLabel *label_12;
    QLineEdit *uname_2;
    QLabel *label_13;
    QLineEdit *paswd_2;
    QLabel *label_14;
    QLineEdit *rcpt_2;
    QLabel *label_15;
    QLineEdit *subject_2;
    QLabel *label_16;
    QPlainTextEdit *msg_2;
    QWidget *layoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *sendBtn_2;
    QPushButton *exitBtn_2;
    QPushButton *pushButton;
    QPushButton *pushButton_5;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(800, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(30, 10, 471, 345));
        formLayout_2 = new QFormLayout(layoutWidget);
        formLayout_2->setObjectName(QStringLiteral("formLayout_2"));
        formLayout_2->setFieldGrowthPolicy(QFormLayout::ExpandingFieldsGrow);
        formLayout_2->setRowWrapPolicy(QFormLayout::WrapLongRows);
        formLayout_2->setVerticalSpacing(9);
        formLayout_2->setContentsMargins(0, 0, 0, 0);
        label_9 = new QLabel(layoutWidget);
        label_9->setObjectName(QStringLiteral("label_9"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, label_9);

        server_2 = new QLineEdit(layoutWidget);
        server_2->setObjectName(QStringLiteral("server_2"));

        formLayout_2->setWidget(0, QFormLayout::FieldRole, server_2);

        label_10 = new QLabel(layoutWidget);
        label_10->setObjectName(QStringLiteral("label_10"));

        formLayout_2->setWidget(1, QFormLayout::LabelRole, label_10);

        port_2 = new QLineEdit(layoutWidget);
        port_2->setObjectName(QStringLiteral("port_2"));

        formLayout_2->setWidget(1, QFormLayout::FieldRole, port_2);

        label_12 = new QLabel(layoutWidget);
        label_12->setObjectName(QStringLiteral("label_12"));

        formLayout_2->setWidget(2, QFormLayout::LabelRole, label_12);

        uname_2 = new QLineEdit(layoutWidget);
        uname_2->setObjectName(QStringLiteral("uname_2"));

        formLayout_2->setWidget(2, QFormLayout::FieldRole, uname_2);

        label_13 = new QLabel(layoutWidget);
        label_13->setObjectName(QStringLiteral("label_13"));

        formLayout_2->setWidget(3, QFormLayout::LabelRole, label_13);

        paswd_2 = new QLineEdit(layoutWidget);
        paswd_2->setObjectName(QStringLiteral("paswd_2"));
        paswd_2->setEchoMode(QLineEdit::Password);

        formLayout_2->setWidget(3, QFormLayout::FieldRole, paswd_2);

        label_14 = new QLabel(layoutWidget);
        label_14->setObjectName(QStringLiteral("label_14"));

        formLayout_2->setWidget(4, QFormLayout::LabelRole, label_14);

        rcpt_2 = new QLineEdit(layoutWidget);
        rcpt_2->setObjectName(QStringLiteral("rcpt_2"));

        formLayout_2->setWidget(4, QFormLayout::FieldRole, rcpt_2);

        label_15 = new QLabel(layoutWidget);
        label_15->setObjectName(QStringLiteral("label_15"));

        formLayout_2->setWidget(5, QFormLayout::LabelRole, label_15);

        subject_2 = new QLineEdit(layoutWidget);
        subject_2->setObjectName(QStringLiteral("subject_2"));

        formLayout_2->setWidget(5, QFormLayout::FieldRole, subject_2);

        label_16 = new QLabel(layoutWidget);
        label_16->setObjectName(QStringLiteral("label_16"));

        formLayout_2->setWidget(6, QFormLayout::LabelRole, label_16);

        msg_2 = new QPlainTextEdit(layoutWidget);
        msg_2->setObjectName(QStringLiteral("msg_2"));

        formLayout_2->setWidget(6, QFormLayout::FieldRole, msg_2);

        layoutWidget_2 = new QWidget(centralwidget);
        layoutWidget_2->setObjectName(QStringLiteral("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(500, 60, 271, 41));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget_2);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        sendBtn_2 = new QPushButton(layoutWidget_2);
        sendBtn_2->setObjectName(QStringLiteral("sendBtn_2"));

        horizontalLayout_2->addWidget(sendBtn_2);

        exitBtn_2 = new QPushButton(layoutWidget_2);
        exitBtn_2->setObjectName(QStringLiteral("exitBtn_2"));

        horizontalLayout_2->addWidget(exitBtn_2);

        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(570, 120, 111, 23));
        pushButton_5 = new QPushButton(centralwidget);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(570, 170, 121, 23));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        label_9->setText(QApplication::translate("MainWindow", "Smtp-server:", Q_NULLPTR));
        server_2->setText(QApplication::translate("MainWindow", "smtp.gmail.com", Q_NULLPTR));
        label_10->setText(QApplication::translate("MainWindow", "Server port:", Q_NULLPTR));
        port_2->setText(QApplication::translate("MainWindow", "465", Q_NULLPTR));
        label_12->setText(QApplication::translate("MainWindow", "Utilisateur:", Q_NULLPTR));
        label_13->setText(QApplication::translate("MainWindow", "Mot de passe", Q_NULLPTR));
        paswd_2->setInputMask(QString());
        label_14->setText(QApplication::translate("MainWindow", "Receveur:", Q_NULLPTR));
        label_15->setText(QApplication::translate("MainWindow", "Sujet:", Q_NULLPTR));
        label_16->setText(QApplication::translate("MainWindow", "Message:", Q_NULLPTR));
        sendBtn_2->setText(QApplication::translate("MainWindow", "Envoyer", Q_NULLPTR));
        exitBtn_2->setText(QApplication::translate("MainWindow", "Quitter", Q_NULLPTR));
        pushButton->setText(QApplication::translate("MainWindow", "Mode \303\251clair\303\251", Q_NULLPTR));
        pushButton_5->setText(QApplication::translate("MainWindow", "Mode noir", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAILER_H
